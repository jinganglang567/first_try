//����ֵ��bool���͵ķº�����ν�ʣ�һ������һԪ
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
class greatf
{
public:
	bool operator()(int val)
	{
		return val>5;
	}
};
void test()
{
	vector<int>v;
	int i=0; 
	for(i=0;i<10;i++)
	{
		v.push_back(i);
	}
	vector<int>::iterator it=find_if(v.begin(),v.end(),greatf());
	if(it!=v.end())
	{
		cout<<*it<<endl;
	}
	else
	{
		cout<<"û�ҵ�"<<endl;
	}
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
