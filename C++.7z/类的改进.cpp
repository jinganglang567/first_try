#include <iostream>
#include <stdlib.h>
#include <cstring>
using namespace std;
class student
{
public:
	string m_name;
	int id;
	void show()
	{
		cout<<m_name<<"  "<<id<<endl;
	}
	void setname(string name)
	{
		m_name=name;
	}
	void setid(int v)
	{
		id=v;
	}
		
}; 
int main()
{
	student s;
	s.setname("����");
	s.setid(1);
	s.show();
	s.setname("��÷÷");
	s.setid(2);
	s.show(); 
	system("pause");
	return 0;
}
