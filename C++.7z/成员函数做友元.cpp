//��Ա��������Ԫ
#include<iostream>
using namespace std;
#include<string>
class building;
class goodday
{
public:
	void visit1();
	void visit2();
	goodday();
	building *b;
};
class building
{
	friend void goodday::visit1();
public:
	string keting;
	building();
private:
	string woshi;
};
building::building()
{
	keting="����";
	woshi="����"; 
}
goodday::goodday()
{
	b=new building;
 } 
void goodday::visit1()
{
	cout<<b->keting<<endl;
	cout<<b->woshi<<endl;
}
void goodday::visit2()
{
	
}
void test()
{
	goodday gg;
	gg.visit1();
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
