//�º�����ʹ��
#include<iostream>
#include<string>
using namespace std;
class myfun
{
public:
	int operator()(int a,int b)
	{
		return a+b;
	}
};
void test()
{
	myfun ff;
	cout<<ff(10,20)<<endl;
}
int main()
{
	test();
	cin.get();
	return 0; 
} 
