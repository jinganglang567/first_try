//�̳�
#include<iostream>
using namespace std;
class jilei
{
public:
	void ok()
	{
		cout<<"shshia"<<endl;
	}
 }; 
class cplus:public jilei
{
public:
	void ok()
	{
		cout<<"dfg"<<endl;
	}

};
void test()
{
	cplus c;
	c.ok();
}
int main()
{
	test();
	cin.get();
	return 0;
}
