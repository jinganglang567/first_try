//��̳�
#include<iostream>
using namespace std;
class base1
{
public:
	base1()
	{
		a=10;
	}
	int a;
 
};
class base2
{
public:
	base2()
	{
		a=20;
	}
	int a;
 
};
class son:public base1,public base2
{
public:
	son()
	{
		a=30;
	}
	int a;
 
};
void test()
{
	son s;
	cout<<s.a<<endl;
	cout<<s.base1::a<<endl;
	cout<<s.base2::a<<endl;
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
