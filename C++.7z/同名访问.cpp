//���ʼ̳��µ�ͬ����Ա
#include<iostream>
using namespace std;
class now
{
public:
	now()
	{
		a=10;
	}
	int a;

};
class nowday:public now//�̳�һ���� 
{
public:
	nowday()
	{
		a=100;
	}
	int a;
};
void test()
{
	nowday p;
	cout<<p.a<<endl;
	cout<<p.now::a<<endl;
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
