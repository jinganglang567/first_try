//引用
#include "cplustou.h"
int main()
{
	//引用语句的结构
	int a=10;
	//创建引用
	int &b=a;//a,b访问同一个内存
	cout<<a<<endl;
	cout<<b<<endl;
	b=100;
	cout<<a<<endl;
	cout<<b<<endl;
	system("pause");
	return 0;
}