//��ģ����̳� 
#include<iostream>
using namespace std;
#include<string>
template<class T>
class base
{
	T name;
 }; 
//�̳�
template<class T1,class T2> 
class next:public base<T2>
{
	T1 S;
};
int main()
{
	next<int,int>b;
	cin.get();
	return 0;
}
