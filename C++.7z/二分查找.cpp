//���ֲ���
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
using namespace std;
void test()
{
	vector<int>v;
	int i=0;
	for(i=0;i<11;i++)
	{
		v.push_back(i);
	}
	bool res=binary_search(v.begin(),v.end(),11);
	if(res)
	{
		cout<<"���ҵ�"<<endl;
		 
	}
	else
	{
		cout<<"������"<<endl;
	}
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
