//ȫ�ֺ�������Ԫ,�쳣�������118�� 
#include<iostream>
#include<string>
using namespace std;
class buliding
{
	friend void fangwen(buliding *b);
public:
	string keting;
	buliding()
	{
		keting="sas";
		woshi="sadadsda";
	}

private:
	string woshi;
};
void fangwen(buliding *b)
{
	cout<<b->keting<<endl;
	cout<<b->woshi<<endl;
}
int main()
{
	buliding s;
	fangwen(&s);
	cin.get();
	return 0;
 } 
