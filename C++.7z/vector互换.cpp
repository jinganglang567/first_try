//��������
#include<iostream>
#include<vector>
using namespace std;
void print(vector<int>&v)
{
	for(vector<int>::iterator it=v.begin();it!=v.end();it++)
	{
		cout<<*it<<" ";
	}
	cout<<endl;
}
void test()
{
	vector<int>v;
	int i=0;
	for(i=0;i<9;i++)
	{
		v.push_back(i);
	}
	cout<<v.at(3)<<endl;
	cout<<v[3]<<endl;
	vector<int>v2;
	for(i=9;i>0;i--)
	{
		v2.push_back(i);
	}
	print(v2);
	//��������
	v.swap(v2);
	print(v);
	print(v2);
	vector<int>v3;
	v3.reserve(1000);//Ԥ��1000���ռ�
	 
}
int main()
{
	test();
	cin.get();
	return 0;
	
 } 
