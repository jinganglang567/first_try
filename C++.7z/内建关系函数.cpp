//�ڽ���ϵ����
#include<iostream>
#include<vector>
#include<algorithm>
#include<functional>
using namespace std;
class big
{
public:
	bool operator()(int a,int b)
	{
		return a>b;
	 } 
};
void test()
{
	vector<int>v;
	int i=10;
	for(i=10;i<100;i+=10)
	{
		v.push_back(i);
	}
	for(vector<int>::iterator it=v.begin();it!=v.end();it++)
	{
		cout<<*it<<" ";
	}
	cout<<endl;
	//sort(v.begin(),v.end(),big());
	sort(v.begin(),v.end(),greater<int>());
	for(vector<int>::iterator it=v.begin();it!=v.end();it++)
	{
		cout<<*it<<" ";
	}
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
