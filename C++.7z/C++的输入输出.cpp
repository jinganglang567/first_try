#include<iostream>
#include<stdlib.h>
//using namespace std;
int main()
{
	std::cout<<"hello world"<<std::endl;
	std::cin.get(); 
	return 0;
}
