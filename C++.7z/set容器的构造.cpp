#include<iostream>
using namespace std;
#include<set>
void print(set<int>&s)
{
	for(set<int>::iterator it=s.begin();it!=s.end();it++)
	{
		cout<<*it<<" ";
	}
	cout<<endl;
}
void test()
{
	//set����ʵ���Զ�����
	set<int>s;
	s.insert(40);
	s.insert(20);
	s.insert(30);
	print(s);
	set<int>::iterator pos=s.find(30);
	if(pos!=s.end())
	{
		cout<<*pos<<"���ҵ�"; 
	 } 
	else
	{
		cout<<"δ�ҵ�"<<endl;
	}
	int num=s.count(30);
	cout<<num;
}
int main()
{
	test();
	cin.get();
	return 0;
}
