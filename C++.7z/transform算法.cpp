//transform�㷨
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
class Transform
{
public:
	int operator()(int val)
	{
		return val+100;
	}
};
class print
{
public:
	void operator()(int val)
	{
		cout<<val<<" ";
	}
};
void test()
{
	vector<int>v;
	int i=10;
	for(i=10;i<100;i+=10)
	{
		v.push_back(i);
	}
	vector<int>v2;
	//�����ȿ��ٿռ䣬�ٰ��˷������� 
	v2.resize(v.size());
	transform(v.begin(),v.end(),v2.begin(),Transform());
	for_each(v2.begin(),v2.end(),print());
	cout<<endl; 
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
