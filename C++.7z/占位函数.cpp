#include "cplustou.h"
void fun(int a,int)
{
	cout<<a<<endl;
}
void fun1(int a,int=10)
{
	cout<<a<<endl;
}
int main()
{
	fun(10,1);//ռλ���� 
	fun1(5);
	system("pause");
	return 0;
 } 
