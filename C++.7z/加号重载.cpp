//�Ӻ��������أ��쳣�����121��
#include<iostream>
using namespace std;
#include<string>
//��Ա����ʵ�ּ�������
class person
{
public:
	person operator+(person &p)
	{
		person temp;
		temp.a=this->a+p.a;
		temp.b=this->b+p.b;
		return temp;
	}
	int a;
	int b;
 }; 
 //ȫ�ֺ�������
/*person operator+(person &p1,person &p2)
{
	person temp;
	temp.a=p1.a+p2.b;
	temp.b=p1.b+p2.b;
	return temp;
 }*/
person operator+(person &p,int num)
{
	person temp;
	temp.a=p.a+num;
	temp.b=p.b+num;
	return temp;
 } 
void test()
{
	person p1;
	person p2;
	p1.a=1;
	p1.b=2;
	p2.a=10;
	p2.b=10;
	person p3=p1+p2; 
	cout<<p3.a<<endl;
	cout<<p3.b<<endl;
	
}
int main()
{
	test();
	person p4;
	person p5=p4+10;
	cout<<p5.a<<endl;
	cout<<p5.b<<endl;
	cin.get();
	return 0;
 } 
