#include<iostream>
#include<stdlib.h>
using namespace std;
class cube
{
public:
	void setl(int ll)
	{
		l=ll;
	}
	void setw(int ww)
	{
		w=ww;
	}
	void seth(int hh)
	{
		h=hh;
	}
	int zhouchang()
	{
		int s=(l+w+h)*4;
		return s;
	}
	bool issame(cube &c2)
	{
		if(h==c2.h&&l==c2.l&&w==c2.w)
			return true;
		else
			return false;
	}//�ֲ�������ȫ�ֺ������� 
private:
	int l;
	int w;
	int h;
};
int main()
{
	cube c1;
	cube c2;
	c1.setl(10);
	c1.setw(10);
	c1.seth(10);
	int s=c1.zhouchang();
	c2.setl(10);
	c2.setw(10);
	c2.seth(10);
	int s2=c2.zhouchang();
	cout<<s<<endl;
	cout<<s2<<endl;
	if(c1.issame(c2))
	{
		cout<<"һ����"<<endl;
	}
	system("pause");
	return 0;
}
