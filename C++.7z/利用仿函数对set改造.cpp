//�º���ʹset�����Ӵ�С����
#include<iostream>
#include<set>
using namespace std;
class comp
{
public:
	bool operator()(int v1,int v2)
	{
		return v1>v2;
	}
};
void print(set<int>&s)
{
	for(set<int>::iterator it=s.begin();it!=s.end();it++)
	{
		cout<<*it<<" ";
	}
	cout<<endl; 
}
void test()
{
	set<int>s;
	s.insert(20);
	s.insert(60);
	s.insert(80);
	s.insert(220);
	print(s);
	set<int,comp>s2;
	s2.insert(90);
	s2.insert(1000);
	s2.insert(20);
	s2.insert(60);
	s2.insert(70);
	for(set<int,comp>::iterator sp=s2.begin();sp!=s2.end();sp++)
	{
		cout<<*sp<<" ";
	}
	cout<<endl;
	
}
int main()
{
	test();
	cin.get();
	return 0;
 } 
