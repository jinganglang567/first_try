#define _CRT_SECURE_NO_DEPRECATE
#define maxsize 100
//ֻ�������λ��
#include <stdio.h>
#include<stdlib.h>
typedef struct
{
	int* top;
	int* base;
	int stacksize;
}stack_number;//��������ջ
typedef struct
{
	char* top;
	char* base;
	int stacksize;
}stack_char;//�����ַ�ջ
int init_stack_c(stack_char& s)
{
	s.base = new char[maxsize];
	if (!s.base)
		return 0;
	else
	{
		s.top = s.base;
		s.stacksize = maxsize;
		return 1;
	}
}//��ʼ��
int init_stack_n(stack_number& s)
{
	s.base = new int[maxsize];
	if (!s.base)
		return 0;
	else
	{
		s.top = s.base;
		s.stacksize = maxsize;
		return 1;
	}
}//��ʼ��
char get_top_c(stack_char& s)
{
	char e;
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		s.top--;
		e = *s.top;
		s.top++;
		return e;
	}
}
int get_top_n(stack_number& s)
{
	int e;
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		s.top--;
		e = *s.top;
		s.top++;//get_top���ܸı�top��ָ�� 
		return e;
	}
}
int push_c(stack_char& s, char e)
{
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		*s.top = e;
		s.top++;
		return 1;
	}
	
}
int push_n(stack_number& s, double e)
{
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		*s.top = e;
		s.top++;
		return 1;
	}
}
char pop_c(stack_char& s)
{
	char e;
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		s.top--;
		e = *(s.top);
		return e;
	}
}
int pop_n(stack_number& s)
{
	int e;
	if (s.top - s.base == s.stacksize)
		return 0;
	else
	{
		s.top--;
		e = *(s.top);
		return e;
	}
}
char compare(char c1, char c2)//�ж����ȼ�
{
	char f;
	switch (c2)
	{
	case '+':
		if (c1 == '#' || c1 == '(')
			f = '<';
		else
			f = '>';
		break;
	case '-':
		if (c1 == '#' || c1 == '(')
			f = '<';
		else
			f = '>';
		break;
	case '*':
		if (c1 == '#' || c1 == '('||c1=='+'||c1=='-')
			f = '<';
		else
			f = '>';
		break;
	case '/':
		if (c1 == '#' || c1 == '(' || c1 == '+' || c1 == '-')
			f = '<';
		else
			f = '>';
		break;
	case '(':
		if (c1 == ')')
			f = '=';
		else
			f = '<';
		break;
	case ')':
		if (c1 == '('||c1=='#')
			f = '=';
		else
			f = '>';
		break;
	case '#':
		if (c1 == '(' || c1 == '#')
			f = '=';
		else
			f = '>';
		break;


	}
	return f;
}
int Operate(double a, char theta, double b)//������ֵ����
{
	//���ж�Ԫ���� a theta b
	int sum=0;
	switch (theta)
	{
	case '+':
		sum = a + b;
		break;
	case '-':
		sum = a - b;
		break;
	case '*':
		sum = a * b;
		break;
	case '/':
		sum = a / b;
		break;
	}
	return sum;
}
//�����Ƿ��������
int IN(char e)
{
	switch (e)
	{
	case '+':
		return 1;
		break;
	case '-':
		return 1;
		break;
	case '*':
		return 1;
		break;
	case '/':
		return 1;
		break;
	case '(':
		return 1;
		break;
	case ')':
		return 1;
		break;
	case '#':
		return 1;
		break;
	default:
		return 0;
	}
}
int caluate(char c)
{
	int i = 0, m = 0;
	int a, b, l;
	char theta;
	char x;

	stack_char optr;//�������
	stack_number opnd;//��������
	init_stack_c(optr);
	push_c(optr, '#');
	init_stack_n(opnd);//��ʼ����ջ��λ����Ͷ�
	while (c != '#' || get_top_c(optr) != '#')
	{
		if (!IN(c))
		{
			push_n(opnd, c-'0');
			c = getchar();
		}//�����������ջ
		else
		{
			switch (compare(get_top_c(optr), c))
			{
			case '<'://ջ��Ԫ������Ȩ��
				push_c(optr, c);
				c = getchar();
				break;
			case '='://�����Ž�����һ���ַ�,������������ʱ���Լ�������Ӱ��
				x = pop_c(optr);
				c = getchar();
				break;
			case '>':
				theta = pop_c(optr);
				b = pop_n(opnd);
				a = pop_n(opnd);
				push_n(opnd, Operate(a, theta, b));
				break;
			}
		}
	}
	l = get_top_n(opnd);
	return l;
}
int main()
{
	char c;
	
	printf("���������ʽ������#��β\n");
	c = getchar();
	int vv = caluate(c);
	printf("%d\n", vv);
	return 0;
}


