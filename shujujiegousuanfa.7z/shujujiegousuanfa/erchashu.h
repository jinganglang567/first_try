
#include <stdio.h>
#include <stdlib.h>
#define Stacksize 100
typedef struct Node
{
	char data;
	struct Node *left;
	struct Node *right;
}node,*no;
typedef struct Stack
{
	no data[Stacksize];//ÿһ���ڵ㶼��һ��no���� 
	int top;
}stack,*sw;
