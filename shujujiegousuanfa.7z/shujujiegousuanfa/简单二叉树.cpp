#include <iostream>
#include <stdlib.h>
using namespace std;
typedef struct Node
{
	int data;
	struct Node *left;
	struct Node *right;
}node;
//ǰ�����
void prebianli(node *n)
{
	if(n!=NULL)
	{
		cout<<n->data<<endl;
		prebianli(n->left);
		prebianli(n->right);
	}
}
int main()
{
	node n1;
	node n2;
	node n3;
	node n4;
	node n5;
	node n6;
	n1.data=5;
	n2.data=6;
	n3.data=7;
	n4.data=8;
	n5.data=9;
	n6.data=10;
	n1.left=&n2;
	n1.right=&n3;
	n2.left=&n4;
	n2.right=NULL;
	n3.left=NULL;
	n3.right=NULL;
	n4.left=NULL;
	n4.right=NULL;
	prebianli(&n1);
	system("pause");
	return 0;
}

