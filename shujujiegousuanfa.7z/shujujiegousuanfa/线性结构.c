#include<stdio.h>
#include<stdlib.h>
#defint big 100
typedef struct
{
	int *a;
	int length;
	//int listsize;
}sqlist;
void init(sqlist *l)
{
	l->a=(int*)malloc(big*sizeof(sqlist));
	l->length=0;//��ʾ���Խṹ�ж��ٸ�Ԫ�� 
}
int locate(sqlist l,int e)
{
	for(int i=0;i++;i<l.length)
	{
		if()
	}
}
int main()
{
	return 0;
 } 
