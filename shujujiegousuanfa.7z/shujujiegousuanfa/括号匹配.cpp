#include <iostream>
#include <stdlib.h>
#define Stacksize 100
#define add 10
using namespace std;
typedef struct
{
	char data[Stacksize];
	int top;
}stack,*sq;
void init(sq s)
{
	s->top=-1;
}//��ʼ�� 
void push(sq s,char e)
{
	s->top++;
	s->data[s->top]=e;
}//ѹջ 
void pop(sq s)
{
	s->top--;
}//��ջ
//ƥ�亯��
int check(char p[])
{
	int i=0;
	stack s;
	init(&s); 
	while(p[i]!='\0')
	{
		if(p[i]=='('||p[i]=='['||p[i]=='{')
			push(&s,p[i]);
		else if(p[i]==')'&&s.data[s.top]=='('||p[i]==']'&&s.data[s.top]=='['||p[i]=='}'&&s.data[s.top]=='{')
			pop(&s);
		else return 0;
		i++;
	}
	if(s.top==-1)
		return 1;
	else
		return 0;
 } 
int main()
{
	char sd[Stacksize];
	printf("���������Ŵ�\n");
	scanf("%s",&sd);
	int m=check(sd);
	if(m)
	{
		printf("ƥ��ɹ�");
	}
	else
	{
		printf("ƥ�䲻�ɹ�");
	} 
	 
	system("pause");
	return 0;
 } 
